package com.g2appdev.teambangan.controller;

public class HelloAppdev {

}
